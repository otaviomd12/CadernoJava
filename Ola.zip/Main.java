class Main {
  public static void main(String[] args) {
    System.out.println("Ola Mundo");
    int Numero = 5;
    System.out.println(Numero);
    int myNum = -1;
    float myFloatNum = 74.54f;
    char myLetter = 'O';
    boolean myBool = false;
    String myText = "Olá";
    System.out.println(myNum);
    System.out.println(myFloatNum);
    System.out.println(myLetter);
    System.out.println(myBool);
    System.out.println(myText);
    //perte dois do codigo
    System.out.println(myText + myBool);
    int x = 5;
    float y = x
    System.out.println(x)
    System.out.println(y)
      double myDouble = 9.78d;
    int myInt = (int) myDouble; // Manual casting: double to int
    System.out.println(myDouble);
    System.out.println(myInt);
  }
}